import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/ui/Navbar";
import { SimpleGradientBg } from "@/components/ui/backgrounds/SimpleGradientBg";
import { Mail, Calendar, RefreshCw, Check, Shield, AlertCircle } from "lucide-react";

export default function Product() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden font-sans selection:bg-primary/30 theme-indigo-vibrant">
      <SimpleGradientBg />
      <Navbar />
      
      <main className="relative pt-32 pb-16 px-4 container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 space-y-4"
        >
          <h1 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-foreground">
            Connect Your Accounts
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            To provide you with the best experience, please authenticate with Gmail and Google Calendar before proceeding.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Gmail Card */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-panel p-8 rounded-2xl flex flex-col items-center text-center group hover:border-primary/50 transition-colors"
          >
            <div className="w-16 h-16 rounded-2xl bg-primary/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
              <Mail className="w-8 h-8 text-blue-400" />
            </div>
            <h2 className="text-2xl font-bold mb-3 text-foreground">Gmail</h2>
            <p className="text-muted-foreground mb-8 flex-grow">
              Connect your Gmail account to manage emails and get email-related assistance
            </p>
            <Button className="w-full bg-[#635BFF] hover:bg-[#5249FF] text-white rounded-full h-12 shadow-[0_0_20px_rgba(99,91,255,0.3)]">
              Connect Gmail
            </Button>
          </motion.div>

          {/* Calendar Card */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-panel p-8 rounded-2xl flex flex-col items-center text-center group hover:border-primary/50 transition-colors"
          >
            <div className="w-16 h-16 rounded-2xl bg-primary/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 relative">
              <Calendar className="w-8 h-8 text-red-400" />
              <div className="absolute top-4 text-[10px] font-bold text-red-400 mt-1">17</div>
            </div>
            <h2 className="text-2xl font-bold mb-3 text-foreground">Google Calendar</h2>
            <p className="text-muted-foreground mb-8 flex-grow">
              Connect your Google Calendar to manage events, meetings, and scheduling
            </p>
            <Button className="w-full bg-[#635BFF] hover:bg-[#5249FF] text-white rounded-full h-12 shadow-[0_0_20px_rgba(99,91,255,0.3)]">
              Connect Calendar
            </Button>
          </motion.div>
        </div>

        {/* Status Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex flex-col md:flex-row gap-4 mb-12"
        >
          <Button variant="outline" className="glass-button text-foreground border-border hover:bg-primary/5 gap-2">
            <RefreshCw className="w-4 h-4" />
            Refresh Status
          </Button>
          <div className="flex-grow glass-panel px-4 py-2 rounded-lg flex items-center justify-center text-muted-foreground text-sm bg-primary/5">
            Please connect at least one service to continue
          </div>
        </motion.div>

        {/* Permissions Info */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass-panel p-6 rounded-xl bg-primary/5 border-border"
        >
          <div className="flex items-center gap-2 mb-4 text-foreground font-medium">
            <AlertCircle className="w-5 h-5 text-primary" />
            <h3>Why do we need these permissions?</h3>
          </div>
          <ul className="space-y-3 text-sm text-muted-foreground pl-2">
            <li className="flex items-start gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
              <span><strong className="text-foreground">Gmail:</strong> To read, compose, and manage your emails</span>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
              <span><strong className="text-foreground">Google Calendar:</strong> To create, update, and manage your calendar events</span>
            </li>
          </ul>
          <div className="mt-6 pt-4 border-t border-border flex items-center gap-2 text-xs text-muted-foreground">
            <Shield className="w-3 h-3 text-emerald-400" />
            Your data is secure and we only access what's necessary for the AI assistant to help you.
          </div>
        </motion.div>
      </main>
    </div>
  );
}
