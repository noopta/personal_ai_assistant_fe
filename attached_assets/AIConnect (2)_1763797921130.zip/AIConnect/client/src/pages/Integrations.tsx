import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/ui/Navbar";
import { SimpleGradientBg } from "@/components/ui/backgrounds/SimpleGradientBg";
import { Mail, Calendar, FileText, Check, ArrowRight, Lock, Lightbulb, HelpCircle } from "lucide-react";

export default function Integrations() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden font-sans selection:bg-primary/30 theme-indigo-vibrant">
      <SimpleGradientBg />
      <Navbar />
      
      <main className="relative pt-32 pb-16 px-4 container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-display font-bold tracking-tight text-white mb-4">
            Integrations
          </h1>
          <p className="text-lg text-muted-foreground">
            Connect AirThreads with your favorite tools to maximize productivity
          </p>
        </motion.div>

        <div className="space-y-8">
          {/* Gmail Integration */}
          <IntegrationCard 
            icon={<Mail className="w-6 h-6 text-blue-400" />}
            title="Gmail"
            description="Manage your emails and send messages through AI assistance"
            delay={0.2}
          >
            <div className="space-y-6">
              <div className="text-xs font-bold text-primary tracking-widest uppercase text-center">Quick Setup</div>
              <div className="grid md:grid-cols-3 gap-4">
                <Step number="1" title="Enable Gmail API" desc="Go to Google Cloud Console, create or select a project, and enable the Gmail API" />
                <Step number="2" title="Create OAuth Credentials" desc='Navigate to Credentials, create OAuth 2.0 Client ID, and set application type to "Desktop"' />
                <Step number="3" title="Configure & Authenticate" desc="Download credentials.json, place in backend directory, then authenticate via the app" />
              </div>
              
              <div className="glass-panel p-4 rounded-lg bg-primary/5 border-primary/20">
                <div className="text-xs font-bold text-primary mb-2 uppercase">Required Scopes</div>
                <div className="flex flex-wrap gap-2">
                  <ScopeBadge>gmail.readonly</ScopeBadge>
                  <ScopeBadge>gmail.send</ScopeBadge>
                  <ScopeBadge>gmail.modify</ScopeBadge>
                </div>
              </div>

              <div className="flex justify-center">
                <Button className="bg-[#635BFF] hover:bg-[#5249FF] text-white rounded-full px-8 shadow-lg shadow-primary/20">
                  Start Setup <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </IntegrationCard>

          {/* Calendar Integration */}
          <IntegrationCard 
            icon={<Calendar className="w-6 h-6 text-red-400" />}
            title="Google Calendar"
            description="Schedule meetings and manage events through natural language"
            delay={0.3}
          >
            <div className="space-y-6">
              <div className="text-xs font-bold text-primary tracking-widest uppercase text-center">Quick Setup</div>
              <div className="grid md:grid-cols-3 gap-4">
                <Step number="1" title="Enable Calendar API" desc="Visit Google Cloud Console and enable the Google Calendar API in your project" />
                <Step number="2" title="Use OAuth Credentials" desc="Reuse Gmail credentials or create new OAuth 2.0 credentials following the same process" />
                <Step number="3" title="Authorize & Connect" desc='Click "Authenticate Calendar" in the app and grant calendar permissions' />
              </div>
              
              <div className="glass-panel p-4 rounded-lg bg-primary/5 border-primary/20">
                <div className="text-xs font-bold text-primary mb-2 uppercase">Required Scopes</div>
                <div className="flex flex-wrap gap-2">
                  <ScopeBadge>calendar</ScopeBadge>
                  <ScopeBadge>calendar.events</ScopeBadge>
                </div>
              </div>

              <div className="flex justify-center">
                <Button className="bg-[#635BFF] hover:bg-[#5249FF] text-white rounded-full px-8 shadow-lg shadow-primary/20">
                  Start Setup <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </IntegrationCard>

          {/* Notion Integration */}
          <IntegrationCard 
            icon={<FileText className="w-6 h-6 text-foreground" />}
            title="Notion"
            description="Create notes, manage projects, and organize knowledge seamlessly"
            badge="Coming Soon"
            delay={0.4}
          >
            <div className="space-y-6 opacity-75">
              <div className="text-xs font-bold text-primary tracking-widest uppercase text-center">Quick Setup</div>
              <div className="grid md:grid-cols-3 gap-4">
                <Step number="1" title="Create Integration" desc='Go to Notion Integrations, create a new integration, and name it (e.g., "AirThreads")' />
                <Step number="2" title="Get Integration Token" desc="Copy the Internal Integration Token and store it securely in your environment variables" />
                <Step number="3" title="Share & Configure" desc="Share Notion pages with your integration and configure backend with the token" />
              </div>
              
              <div className="glass-panel p-4 rounded-lg bg-primary/5 border-primary/20">
                <div className="text-xs font-bold text-primary mb-2 uppercase">Capabilities</div>
                <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2"><Check className="w-3 h-3 text-emerald-400" /> Read and write page content</div>
                  <div className="flex items-center gap-2"><Check className="w-3 h-3 text-emerald-400" /> Create new pages and databases</div>
                  <div className="flex items-center gap-2"><Check className="w-3 h-3 text-emerald-400" /> Search across workspace</div>
                  <div className="flex items-center gap-2"><Check className="w-3 h-3 text-emerald-400" /> Update properties and metadata</div>
                </div>
              </div>

              <div className="flex justify-center">
                <Button disabled className="bg-muted text-muted-foreground rounded-full px-8">
                  Start Setup <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </IntegrationCard>
        </div>

        {/* Info Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-12">
           <InfoCard 
             icon={<Lightbulb className="w-5 h-5 text-yellow-400" />}
             title="Quick Tips"
             desc="Ensure all required APIs are enabled in your Google Cloud Console before attempting authentication."
             delay={0.5}
           />
           <InfoCard 
             icon={<Lock className="w-5 h-5 text-emerald-400" />}
             title="Security"
             desc="Never share your credentials or tokens publicly. Store them securely in environment variables."
             delay={0.6}
           />
           <InfoCard 
             icon={<HelpCircle className="w-5 h-5 text-blue-400" />}
             title="Support"
             desc="Having trouble? Check that your OAuth consent screen is properly configured with test users."
             delay={0.7}
           />
        </div>
      </main>
    </div>
  );
}

function IntegrationCard({ icon, title, description, children, badge, delay }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="glass-panel rounded-xl overflow-hidden"
    >
      <div className="p-6 border-b border-border flex items-center justify-between bg-primary/5">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-background/50 flex items-center justify-center border border-border">
            {icon}
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-bold text-foreground">{title}</h2>
              {badge && <span className="text-[10px] font-bold bg-primary/20 text-primary px-2 py-0.5 rounded-full uppercase tracking-wide border border-primary/30">{badge}</span>}
            </div>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
        </div>
      </div>
      <div className="p-8 bg-card/50">
        {children}
      </div>
    </motion.div>
  );
}

function Step({ number, title, desc }: any) {
  return (
    <div className="glass-panel p-4 rounded-lg bg-background/50 border-border hover:bg-background/80 transition-colors">
      <div className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold mb-3 shadow-[0_0_10px_rgba(99,91,255,0.5)]">
        {number}
      </div>
      <h3 className="font-bold text-sm text-foreground mb-2">{title}</h3>
      <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}

function ScopeBadge({ children }: any) {
  return (
    <code className="text-[10px] bg-muted border border-border rounded px-2 py-1 font-mono text-primary">
      {children}
    </code>
  );
}

function InfoCard({ icon, title, desc, delay }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="glass-panel p-6 rounded-xl"
    >
      <div className="flex items-center gap-3 mb-3">
        {icon}
        <h3 className="font-bold text-foreground">{title}</h3>
      </div>
      <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
    </motion.div>
  );
}
