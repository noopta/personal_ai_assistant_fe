import { motion } from "framer-motion";
import { Navbar } from "@/components/ui/Navbar";
import { SimpleGradientBg } from "@/components/ui/backgrounds/SimpleGradientBg";
import { Lock, User, Zap, Heart, Mail } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden font-sans selection:bg-primary/30 theme-indigo-vibrant">
      <SimpleGradientBg />
      <Navbar />
      
      <main className="relative pt-32 pb-16 px-4 container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h1 className="text-4xl md:text-6xl font-display font-bold tracking-tight text-foreground mb-6">
            About AirThreads
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Revolutionizing productivity through intelligent task management and seamless integrations
          </p>
        </motion.div>

        {/* Our Story */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-24"
        >
          <h2 className="text-3xl font-display font-bold text-center mb-8 text-foreground">Our Story</h2>
          <div className="glass-panel p-8 md:p-12 rounded-2xl bg-primary/5 border-border space-y-6 text-lg text-muted-foreground leading-relaxed">
            <p>
              AirThreads was founded in 2025 with a simple yet powerful vision: to transform how people engage with their productivity tools. As an engineer balancing work, multiple projects, and self-care, I naturally gravitated toward apps to manage my routines—Calendar for event planning, Gmail for business communications, and Notion for note-taking and thought dumps.
            </p>
            <p>
              However, in a world with countless productivity tools, I found myself spread thin across different platforms. Notes scattered between iPhone Notes and Notion, duplicate calendar entries across Google Calendar and my phone—it became overwhelming. The most frustrating part? These apps had zero cross-sync capabilities, and interacting with them required constant manual effort.
            </p>
            <p>
              In our increasingly competitive world, I needed a way to use my platforms asynchronously and share data between them seamlessly. Imagine sifting through Gmail for job opportunities and instantly blocking calendar time to prepare, while the postings are saved to Notion for later review.
            </p>
          </div>
        </motion.section>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-8 mb-24">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-panel p-8 rounded-xl border-l-4 border-l-primary"
          >
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mb-4 text-2xl">🎯</div>
            <h3 className="text-2xl font-bold text-foreground mb-3">My Mission</h3>
            <p className="text-muted-foreground">
              To empower individuals with AI-driven task management that eliminates friction, reduces cognitive load, and amplifies human potential. I believe technology should work for you, not against you.
            </p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-panel p-8 rounded-xl border-l-4 border-l-accent"
          >
            <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center mb-4 text-2xl">🚀</div>
            <h3 className="text-2xl font-bold text-foreground mb-3">My Vision</h3>
            <p className="text-muted-foreground">
              A world where everyone can focus on meaningful work while AI handles the routine. I envision seamless productivity ecosystems that understand context, anticipate needs, and deliver results effortlessly.
            </p>
          </motion.div>
        </div>

        {/* Core Values */}
        <section className="mb-24">
          <h2 className="text-3xl font-display font-bold text-center mb-12 text-foreground">Core Values</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <ValueCard icon={<Lock className="text-emerald-400" />} title="Privacy First" desc="Your data belongs to you. AirThreads implements enterprise-grade security measures and transparent privacy practices." />
            <ValueCard icon={<User className="text-blue-400" />} title="User-Centric Design" desc="Every feature starts with understanding real user needs. We prioritize intuitive experiences over flashy features." />
            <ValueCard icon={<Zap className="text-yellow-400" />} title="Continuous Innovation" desc="Technology evolves rapidly. We're committed to staying at the forefront of AI and productivity tools." />
            <ValueCard icon={<Heart className="text-red-400" />} title="User Empowerment" desc="AirThreads is built to empower users with tools that integrate seamlessly into their workflows." />
          </div>
        </section>

        {/* Founder */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass-panel p-8 md:p-12 rounded-2xl bg-gradient-to-br from-primary/10 to-transparent border-primary/20 mb-24"
        >
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="w-40 h-40 md:w-48 md:h-48 rounded-full overflow-hidden border-4 border-primary/30 flex-shrink-0 shadow-2xl">
               {/* Placeholder for founder image */}
               <img 
                 src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop" 
                 alt="Anu I." 
                 className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
               />
            </div>
            <div>
              <h2 className="text-3xl font-display font-bold text-foreground mb-1">Anu I.</h2>
              <p className="text-primary font-medium mb-4 uppercase tracking-wide text-sm">Founder</p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                I'm a software engineer with a passion for building AI-powered productivity solutions. With experience in full-stack development and system architecture, I focus on creating seamless user experiences that solve real workflow challenges.
              </p>
              <p className="text-sm text-muted-foreground italic opacity-70">
                "And yes, that is a film photo of me holding a Modelo in a random Mexican spot on Mission Street..."
              </p>
            </div>
          </div>
        </motion.section>

        {/* Get in Touch */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center glass-panel p-12 rounded-2xl"
        >
          <h2 className="text-3xl font-bold text-foreground mb-4">Get in Touch</h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            I'm always excited to hear from users and potential partners. Whether you have questions, feedback, or collaboration ideas, don't hesitate to reach out.
          </p>
          <a href="mailto:support@airthreads.ai" className="inline-flex items-center gap-2 text-primary hover:text-foreground transition-colors text-lg font-medium">
            <Mail className="w-5 h-5" />
            support@airthreads.ai
          </a>
        </motion.div>

      </main>
    </div>
  );
}

function ValueCard({ icon, title, desc }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="glass-panel p-6 rounded-xl hover:bg-primary/5 transition-colors"
    >
      <div className="flex items-center gap-3 mb-3">
        <div className="p-2 rounded-lg bg-primary/10">
          {icon}
        </div>
        <h3 className="font-bold text-foreground text-lg">{title}</h3>
      </div>
      <p className="text-muted-foreground leading-relaxed">
        {desc}
      </p>
    </motion.div>
  );
}
