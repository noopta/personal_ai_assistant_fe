import { motion } from "framer-motion";

export function SimpleGradientBg() {
  return (
    <div className="absolute inset-0 overflow-hidden bg-background -z-10">
      <div className="absolute top-0 left-0 right-0 h-[500px] bg-gradient-to-b from-primary/5 to-transparent" />
      <div className="absolute -top-[200px] -right-[200px] w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px]" />
      <div className="absolute top-[20%] -left-[100px] w-[400px] h-[400px] bg-accent/5 rounded-full blur-[100px]" />
    </div>
  );
}
